<?php
// header("Content-Type: application/json");
$data = ["message" => "Hello, world!"];
echo json_encode($data);
?>
